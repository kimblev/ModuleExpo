CONTENTS OF THIS FILE
---------------------

 * Introduction
 * Requirements
 * Installation
 * Configuration
 * Maintainers


INTRODUCTION
------------

Palindrome Test is a simple demonstration of a custom module. It does not 
interact with database, configuration or any other module. 

When enabled, the module will present a form at <my-domain>/palindrome-test, 
allowing a user to enter a string to determine if it is spelled the same 
frontwards and backwards.

***This moudle is not intended for use on production sites.***


REQUIREMENTS
------------

No special requirements.


INSTALLATION
------------

 * Install as you would normally install a contributed Drupal module.
   See: https://www.drupal.org/node/895232 for further information.


CONFIGURATION
-------------

The module has no menu or modifiable settings. There is no configuration.


MAINTAINERS
-----------

Current maintainers:
 * Kimble Vardaman (kimble) - https://www.drupal.org/u/kimble

